<?php

defined('BASEPATH') or exit('No direct script access allowed');
$clients = db_prefix() . 'clients';
if (!$CI->db->field_exists('pr_name', $clients)) {
    $CI->db->query("ALTER TABLE `" . $clients . "` ADD `name` varchar(191)  AFTER `company`;");
}
$clients = db_prefix() . 'clients';
if (!$CI->db->field_exists('pr_surname', $clients)) {
    $CI->db->query("ALTER TABLE `" . $clients . "` ADD `surname` varchar(191)  AFTER `name`;");
}
$clients = db_prefix() . 'clients';
if (!$CI->db->field_exists('pr_birth_date', $clients)) {
    $CI->db->query("ALTER TABLE `" . $clients . "` ADD `birth_date` varchar(191)  AFTER `surname`;");
}

$clients = db_prefix() . 'clients';
if (!$CI->db->field_exists('pr_mobile', $clients)) {
    $CI->db->query("ALTER TABLE `" . $clients . "` ADD `mobile` varchar(191) AFTER `birth_date`;");
}

$clients = db_prefix() . 'clients';
if (!$CI->db->field_exists('pr_email', $clients)) {
    $CI->db->query("ALTER TABLE `" . $clients . "` ADD `email` varchar(191) AFTER `mobile`;");
}


if (!$CI->db->table_exists(db_prefix() . 'patrimoines')) {
    $CI->db->query('CREATE TABLE `' . db_prefix() . 'patrimoines` (
  `id` int(11) NOT NULL,
  `resident` int(11) NOT NULL,
  `resident_from` date NOT NULL,
  `fiscally_from` date NOT NULL,
  `interview_date` date NOT NULL,
  `family_status_id` int(11) NOT NULL,
  `job` varchar(191) NOT NULL,
  `retirement_date` date,
  `social_security_number` varchar(191),
  `spouse_name` varchar(191) NOT NULL,
  `spouse_surname` varchar(191) NOT NULL,
  `spouse_birth_date` date NOT NULL,
  `spouse_social_security_number` varchar(191),
  `wedding_date` date,
  `matrimonial_regime` varchar(191),
  `donation_btw_spouses` int(11),
  `spouse_mobile` varchar(191),
  `spouse_email` varchar(191),
  `description` text,
  `status` int(11) NOT NULL,
  `clientid` int(11) NOT NULL,
  `billing_type` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `deadline` date DEFAULT NULL,
  `patrimoine_created` date NOT NULL,
  `date_finished` datetime DEFAULT NULL,
  `progress` int(11),
  `progress_from_tasks` int(11) NOT NULL,
  `patrimoine_cost` decimal(15,2) DEFAULT NULL,
  `patrimoine_rate_per_hour` decimal(15,2) DEFAULT NULL,
  `estimated_hours` decimal(15,2) DEFAULT NULL,
  `addedfrom` int(11) NOT NULL,
  `contact_notification` int(11),
  `notify_contacts` text
) ENGINE=InnoDB DEFAULT CHARSET=' . $CI->db->char_set . ';');

    $CI->db->query('ALTER TABLE `' . db_prefix() . 'patrimoines`
  ADD PRIMARY KEY (`id`);');

    $CI->db->query('ALTER TABLE `' . db_prefix() . 'patrimoines`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;');
}
