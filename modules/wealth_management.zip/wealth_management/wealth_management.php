<?php

/**
 * Ensures that the module init file can't be accessed directly, only within the application.
 */
defined('BASEPATH') or exit('No direct script access allowed');

/*
Module Name: Wealth Management Perfex CRM Module
Description: Wealth Management module description.
Version: 2.8.4
Requires at least: 2.8.4
*/

define('WEALTH_MANAGEMENT_MODULE_NAME', 'wealth_management');

$CI = &get_instance();

hooks()->add_filter('module_wealth_management_action_links', 'module_wealth_management_action_links');
hooks()->add_action('admin_init', 'wealth_management_module_init_menu_items');


/**
 * Load the module helper
 */
$CI->load->helper(WEALTH_MANAGEMENT_MODULE_NAME . '/wealth_management');

/**
 * Register activation module hook
 */
register_activation_hook(WEALTH_MANAGEMENT_MODULE_NAME, 'wealth_management_module_activation_hook');

function wealth_management_module_activation_hook()
{
    $CI = &get_instance();
    require_once(__DIR__ . '/install.php');
}

/**
 * Register language files, must be registered if the module is using languages
 */
register_language_files(WEALTH_MANAGEMENT_MODULE_NAME, [WEALTH_MANAGEMENT_MODULE_NAME]);


function module_wealth_management_action_links($actions)
{
    $actions[] = '<a href="' . admin_url('wealth_management') . '"></a>';

    return $actions;
}

/**
 * Init FICHE_CLIENT module menu items in setup in admin_init hook
 * @return null
 */
function wealth_management_module_init_menu_items()
{
    if (is_admin()) {
        $CI = &get_instance();
        $CI->app_menu->add_sidebar_menu_item('wealth-management', [
            'collapse' => true,
            'name'     => 'Wealth Management',
            'position' => 3,
        ]);

        $CI->app_menu->add_sidebar_children_item('wealth-management', [
            'slug'     => 'main-fiche-setup',
            'name'     =>  'Fiche Client',
            'href'     => admin_url('wealth_management'),
            'position' => 1,
        ]);
    }
}
